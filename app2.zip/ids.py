IDS = {
    "SNAPSHOT_ID": "SNAPSHOT_ID",
    "LOCATION": "LOCATION",
    "GRAPH-1": "GRAPH-1",
    "GRAPH-2": "GRAPH-2",
    "GRAPH-3": "GRAPH-3",
}
